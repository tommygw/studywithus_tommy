

<?php $__env->startSection('title', 'Edit Product'); ?>

<?php $__env->startSection('contents'); ?>
    <h1 class="mb-1">Edit Data Produk</h1>
    <hr />

    <form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data" >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="title" value="<?php echo e($product->title); ?>" class="form-control">
            </div>
            <div class="col">
                <input type="text" name="sku" value="<?php echo e($product->sku); ?>" class="form-control">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="price" value="<?php echo e($product->price); ?>" class="form-control">
            </div>
            <div class="col">
                <textarea type="text" name="description" class="form-control"><?php echo e($product->description); ?></textarea>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col">
                <label for="">Upload Image</label>
                <input type="file" name="image" id="inputImage" value="<?php echo e($product->image_uri); ?>" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row">
            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studywithus\resources\views/products/edit.blade.php ENDPATH**/ ?>