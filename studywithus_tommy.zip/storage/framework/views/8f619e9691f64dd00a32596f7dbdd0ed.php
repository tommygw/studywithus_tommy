

<?php $__env->startSection('title', 'Index User'); ?>

<?php $__env->startSection('contents'); ?>
    <h1 class="mb-1">Tambah Data User</h1>
    <hr />

    <form action="<?php echo e(route('users.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="name" placeholder="Masukkan nama user" class="form-control">
            </div>
            <div class="col">
                <input type="email" name="email" placeholder="Masukkan email user" class="form-control">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-6">
                <input type="password" name="password" placeholder="Masukkan password" class="form-control">
            </div>
            <div class="col">
                <label for="level" class="form-label"><strong>Roles</strong></label>
                <select name="level" id="level" class="form-select">
                    <option value="Admin">Admin</option>
                    <option value="User">User</option>
                </select>
            </div>
        </div>
        
        <div class="row">
            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studywithus\resources\views/users/create.blade.php ENDPATH**/ ?>