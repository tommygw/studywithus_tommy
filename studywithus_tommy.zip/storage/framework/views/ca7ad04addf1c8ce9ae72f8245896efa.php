

<?php $__env->startSection('title', 'Show User'); ?>

<?php $__env->startSection('contents'); ?>

    <h1 class="mb-1">Lihat Data User</h1>
     <hr />

        <div class="row mb-3">
            <div class="col">
            <label for=""> nama</label>
                <input readonly type="text" name="title" value="<?php echo e($user->name); ?>" class="form-control">
            </div>
            <div class="col">
            <label for=""> email</label>
                <input readonly type="text" name="sku" value="<?php echo e($user->email); ?>" class="form-control">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
            <label for=""> level</label>
                <input readonly type="text" name="price" value="<?php echo e($user->level); ?>" class="form-control">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
            <label for=""> Created_at</label>
                <input readonly type="text" name="price" value="<?php echo e($user->created_at); ?>" class="form-control">
            </div>
            <div class="col">
                <label for=""> Updated_at</label>
                <input readonly type="text" name="description" value="<?php echo e($user->updated_at); ?>" class="form-control">
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studywithus\resources\views/users/show.blade.php ENDPATH**/ ?>