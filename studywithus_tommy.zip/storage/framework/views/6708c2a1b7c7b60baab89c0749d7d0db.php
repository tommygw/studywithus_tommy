

<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('contents'); ?>
    <h1 class="mb-1">Edit Data User</h1>
    <hr />

    <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control">
            </div>
            <div class="col">
                <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
                <label for="level" class="form-label">Level</label>
                <select name="level" id="level" class="form-select">
                    <option value="Admin" <?php echo e($user->level == 'Admin' ? 'selected' : ''); ?>>Admin</option>
                    <option value="User" <?php echo e($user->level == 'User' ? 'selected' : ''); ?>>User</option>
                </select>
            </div>
        </div>

        <div class="row">
            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studywithus\resources\views/users/edit.blade.php ENDPATH**/ ?>