

<?php $__env->startSection('title', 'Show Product'); ?>

<?php $__env->startSection('contents'); ?>

    <h1 class="mb-1">Lihat Data Produk</h1>
     <hr />

        <div class="row mb-3">
            <div class="col">
            <label for=""> title</label>
                <input readonly type="text" name="title" value="<?php echo e($product->title); ?>" class="form-control">
            </div>
            <div class="col">
            <label for=""> sku</label>
                <input readonly type="text" name="sku" value="<?php echo e($product->sku); ?>" class="form-control">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
            <label for=""> price</label>
                <input readonly type="text" name="price" value="<?php echo e($product->price); ?>" class="form-control">
            </div>
            <div class="col">
            <label for=""> description</label>
                <textarea readonly type="text" name="description" class="form-control"><?php echo e($product->description); ?></textarea>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
            <label for=""> Created_at</label>
                <input readonly type="text" name="price" value="<?php echo e($product->created_at); ?>" class="form-control">
            </div>
            <div class="col">
                <label for=""> Updated_at</label>
                <input readonly type="text" name="description" value="<?php echo e($product->updated_at); ?>" class="form-control">
            </div>
        </div>

        <div class="row mb-3">
            <div class="col">
                <label for=""> Image</label>
                <img src="<?php echo e(asset($product->image_uri)); ?>" style="width:150px; height: 150px;" alt="<?php echo e($product->image_uri); ?>" scrset="">                
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studywithus\resources\views/products/show.blade.php ENDPATH**/ ?>